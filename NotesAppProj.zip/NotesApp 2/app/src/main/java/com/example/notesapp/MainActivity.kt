package com.example.notesapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(), NoteClickInterface, NoteClickDeleteInterface {

    lateinit var RecV: RecyclerView
    lateinit var AddNoteB: FloatingActionButton
    lateinit var viewModal: NoteViewModal

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        RecV = findViewById(R.id.RecV)
        AddNoteB = findViewById(R.id.AddNoteButton)
        RecV.layoutManager = LinearLayoutManager(this)

        val NoteAdapter = NoteAdapter(this,this,this)
        RecV.adapter = NoteAdapter
        viewModal = ViewModelProvider(this,ViewModelProvider.AndroidViewModelFactory.getInstance(application)).get(NoteViewModal::class.java)
        viewModal.allNotes.observe(this, {list->
            list?.let {
            NoteAdapter.updateList(it)
            }
        })
        AddNoteB.setOnClickListener{
            val intent = Intent(this@MainActivity,AddEditNoteActivity::class.java)
            startActivity(intent)
            this.finish()
        }
    }
    override fun onDeleteIconClick(note: Note){
        viewModal.deleteNote(note)
        Toast.makeText(this,"${note.noteTitle} Deleted!", Toast.LENGTH_LONG).show()
    }
    override fun onNoteClick(note: Note){
        val intent = Intent(this@MainActivity,AddEditNoteActivity::class.java)
        intent.putExtra("noteType", "Edit")
        intent.putExtra("noteTitle",note.noteTitle)
        intent.putExtra("noteDescription",note.noteDescription)
        intent.putExtra("noteID", note.id)
        startActivity(intent)
        this.finish()
    }
}