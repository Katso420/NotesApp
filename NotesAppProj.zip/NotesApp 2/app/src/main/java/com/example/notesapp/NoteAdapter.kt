package com.example.notesapp

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class NoteAdapter (val context: Context,
                   val noteClickInterface: NoteClickInterface,
                   val noteClickDeleteInterface: NoteClickDeleteInterface):
    RecyclerView.Adapter<NoteAdapter.ViewHolder>() {

    private val allNotes = ArrayList<Note>()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

    val note = itemView.findViewById<TextView>(R.id.NoteTitle)
    val time = itemView.findViewById<TextView>(R.id.TimeStamp)
    val delete = itemView.findViewById<ImageView>(R.id.Delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.note_item,parent,false)
        return ViewHolder(itemView)

    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.note.setText(allNotes.get(position).noteTitle)
        holder.time.setText("Last Updated: " + allNotes.get(position).timestamp)

        holder.delete.setOnClickListener{
            noteClickDeleteInterface.onDeleteIconClick(allNotes.get(position))
        }

        holder.itemView.setOnClickListener{
            noteClickInterface.onNoteClick(allNotes.get(position))
        }
    }

    override fun getItemCount(): Int {
        return allNotes.size
    }

    fun updateList(newList:List<Note>){
        allNotes.clear()
        allNotes.addAll(newList)
        notifyDataSetChanged()
    }
}

interface NoteClickDeleteInterface{
    fun onDeleteIconClick(note: Note)
}

interface NoteClickInterface {
    fun onNoteClick(note: Note)
}